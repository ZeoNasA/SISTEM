<?php include 'inc/header.php'; ?>
<?php
Session::checkSession();
$question = $exm->getQuestion();
$total = $exm->getTotalRows();
?>
<div class="main">
<h1>Welcome to Online Exam</h1>
	<div class="starttest">
		<h2>Ujian Penilaian</h2>
		<p>Ini adalah soalan pilihan jawapan untuk menguji penilaian anda</p>

		<ul>
			<li><strong>Soalan Keseluruhan:</strong> <?php echo $total; ?></li>
			<li><strong>Jenis soalan:</strong>Pilihan Jawapan</li>
		</ul>

		<a href="test.php?q=<?php echo $question['quesNo']; ?>">Start Test</a>

	</div>

  </div>
<?php include 'inc/footer.php'; ?>