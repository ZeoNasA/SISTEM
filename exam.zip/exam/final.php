<?php include 'inc/header.php'; ?>
<?php
Session::checkSession();
?>
<div class="main">
<h1>Anda telah selesai menjawab</h1>

<div class="starttest">
	<p>Tahniah! Anda telah selesai menjawab</p>
	<p>Markah: 

		<?php 
		if (isset($_SESSION['score'])) {
			echo $_SESSION['score'];
			unset($_SESSION['score']);
		}
		 ?>

	</p>

	<a href="viewans.php">Tunjuk Jawapan</a>
	<a href="starttest.php">Mula Kembali</a>
</div>
	
  </div>
<?php include 'inc/footer.php'; ?>