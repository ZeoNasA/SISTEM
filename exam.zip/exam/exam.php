<?php include 'inc/header.php'; ?>
<?php
Session::checkSession();
?>
<div class="main">
<h1>Selamat datang ke Online Exam - Mula Sekarang</h1>
	<div class="segment" style="margin-right:30px;">
		<img src="img/online_exam.png"/>
	</div>
	<div class="segment">
	<h2>Mula Menjawab</h2>
	<ul>
		<li><a href="starttest.php">Mula Sekarang...</a></li>
	</ul>
	</div>
	
  </div>
<?php include 'inc/footer.php'; ?>