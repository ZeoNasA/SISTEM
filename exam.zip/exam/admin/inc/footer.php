 </section>
<section class="footeroption">
		<h2><?php echo "ZeoN System"; ?></h2>
	</section>
</div>
</body>
</html>