<?php 
    $filepath = realpath(dirname(__FILE__));
	include_once ($filepath.'/inc/header.php');
	include_once ($filepath.'/../classes/Exam.php');
	$exm = new Exam();
?>
<style>
.adminpanel{width: 480px;color: #999;margin: 20px auto 0;padding: 30px;border: 1px solid #ddd;}	

</style>

<?php 
	if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	$addQue = $exm->addQuestions($_POST);
	}
	//Get Total
	$total = $exm->getTotalRows();
	$next = $total+1;

 ?>

<div class="main">
<h1>Admin Panel - Tambah Soalan</h1>

<?php 
if (isset($addQue)) {
	echo $addQue;
}

 ?>

<div class="adminpanel">
	
	<form action="" method="post">
		<table>
			<tr>
				<td>Nombor Soalan</td>
				<td>:</td>
				<td><input type="number" value="<?php 
					if(isset($next)){
						echo $next;
					}

					 ?>"  name="quesNo"></td>
			</tr>

			<tr>
				<td>Soalan</td>
				<td>:</td>
				<td><input type="text"  name="Soalan" placeholder="Masukkan Soalan..." required></td>
			</tr>

			<tr>
				<td>Pilihan Satu</td>
				<td>:</td>
				<td><input type="text"  name="Jawapan1" placeholder="Masukkan Soalan..." required></td>
			</tr>

			<tr>
				<td>Pilihan Dua</td>
				<td>:</td>
				<td><input type="text"  name="Jawapan2" placeholder="Masukkan Soalan..." required></td>
			</tr>

			<tr>
				<td>Pilihan Tiga</td>
				<td>:</td>
				<td><input type="text"  name="Jawapan3" placeholder="Masukkan Soalan..." required></td>
			</tr>

			<tr>
				<td>Pilihan Empat</td>
				<td>:</td>
				<td><input type="text"  name="Jawapan4" placeholder="Masukkan Soalan..." required></td>
			</tr>

			<tr>
				<td>Nombor Betul</td>
				<td>:</td>
				<td><input type="number"  name="rightAns" required></td>
			</tr>

			<tr>
				
				<td colspan="3" align="center">
					<input type="submit" value="Tambah Soalan">
				</td>
			</tr>

		</table>


	</form>

</div>

	
</div>
<?php include 'inc/footer.php'; ?>